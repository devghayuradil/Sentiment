from flask_cors.core import serialize_option
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from Predict_Text import predict_text
from tensorflow.keras.models import load_model
import pickle
from werkzeug.utils import secure_filename
import os
import pandas as pd
import matplotlib.pyplot as plt 
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


filepath="model/sentiment_model.h5"
model1 = load_model(filepath)

with open('model/tokenizer.pickle', 'rb') as handle:
    tokenizer1= pickle.load(handle)

@app.route('/predict', methods=['post'])
def pas():
    tw = request.form['tweet']
    cl = "show"
    label, conf = predict_text([tw], model1, tokenizer1)
    conf=conf[0][0]
    conf = conf * 100
    conf = int(conf)
    return render_template('index.html', tw=tw,cl=cl,label=label[0],conf=conf)
label, conf = predict_text(["hello", 'abc','not'], model1, tokenizer1)
# print('========================>>>>>>>>>>>>>' , conf)
# print('========================>>>>>>>>>>>>>' , label)


@app.route('/csv', methods=['post'])
def pasCsv():
    csv_file = request.files['upload']
    csv_read = pd.read_fwf(csv_file,encoding='latin-1')
    col = csv_read.columns[0]
    csv_read_list = csv_read[col].to_list()
    prediction, _ = predict_text(csv_read_list, model1, tokenizer1)
    csv_data = {'tweets' : csv_read_list, 'labels' : prediction}
    predicted_csv = pd.DataFrame(data=csv_data)
    total = len(predicted_csv)
    positive_tweets = len(predicted_csv[predicted_csv['labels']=='Positive'])
    pos_percent = (positive_tweets/total)*100
    neg_percent = (total-positive_tweets)/total*100
    outputToSend = predicted_csv.to_html(index=False)
    csv_show = "show"
    return render_template('about.html',pos_percent=pos_percent,neg_percent=neg_percent,csv_show=csv_show,tweets=outputToSend)

@app.route('/about')
def about():
 return render_template('about.html')

@app.route('/index')
def homeIndex():
 return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
